mkv.exe

Made by N17Pro3426 (@nazar7346)
I made this malware in C++!
Credits to Sensist2K05 (@lebob2060/@Sensist2K05/@lawrenciumdoesthings) for the idea and some payloads

This is my new malware!

Hi, Pawin Vechanon, yedb0y33k, Marlon2210, Comium92 and more!

:]