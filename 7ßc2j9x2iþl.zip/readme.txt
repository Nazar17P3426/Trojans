7ßc2j9x2iþl.exe

Made by N17Pro3426 (@nazar7346)
and fr4ctalz (@fr4ctalz638)

We made this malware in C++!

This is our new malware!

Hi, pankoza!

 #    #

#      #
 ######