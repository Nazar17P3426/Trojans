saskeghfb1.exe

Made by N17Pro3426 (@nazar7346)
I made this malware in C++!

This is my new malware!

Hi, fr4ctalz, pankoza, I am Wynn and yedb0y33k!

 #    #

#      #
 ######