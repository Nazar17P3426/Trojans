nrtzgrno31.exe

Made by N17Pro3426 (@nazar7346)
and pankoza (@pankoza / @pankoza2)

We made this malware in C++!

This is our new malware!

Hi, fr4ctalz!

 #    #

#      #
 ######