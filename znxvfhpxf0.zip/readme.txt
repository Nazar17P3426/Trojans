znxvfhpxf0.exe

Made by N17Pro3426 (@nazar7346)
I made this malware in C++!
Credits to Sensist2K05 (@LawisGreffin666SKARY/@Sensist2K052.0/@lawrenciumdoesthings) for the idea and some payloads

This is my new malware!

Hi, I am Wynn, yedb0y33k, Marlon2210, Comium92 and more!

:]