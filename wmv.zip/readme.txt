wmv.exe

Made by N17Pro3426 (@nazar7346)
I made this malware in C++!

This is my new malware!

Hi, Pawin Vechanon, yedb0y33k, Marlon2210, Comium92 and more!

:]