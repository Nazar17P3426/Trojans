azarizonium.exe

Made by N17Pro3426 (@nazar7346)
I made this malware in C++!
Credits to Maxi2022gt for the window mover

This is my new malware!

Hi, I am Wynn, yedb0y33k, Marlon2210, Comium92 and more!

:]