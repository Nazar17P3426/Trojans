superdeath.exe

Made by N17Pro3426 (@nazar7346),
fr4ctalz (@fr4ctalz638) and pankoza
(@pankoza / @pankoza2)

We made this malware in C++!

This is our new malware!

Hi, Crypto NWO and RainflowBoi!

 #    #

#      #
 ######