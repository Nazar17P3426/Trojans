cadaverine.exe

Made by N17Pro3426 (@nazar7346)
I made this malware in C++!

This is my new malware!

Hi, Hexademical, UltraDasher965, yedb0y33k, Marlon2210 and more!

:]