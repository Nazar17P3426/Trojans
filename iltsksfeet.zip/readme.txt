iltsksfeet.exe

Made by N17Pro3426 (@nazar7346), WinMalware
(@Win_malware) and Null_Y317K (@Null_Y317K)

We made this malware in C++!

This is our new malware!

Hi, I am Wynn, yedb0y33k, Marlon2210, Comium92 and more!

 #    #

#      #
 ######